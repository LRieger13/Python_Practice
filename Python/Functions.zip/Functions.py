def main():
    greeting()

def greeting():
   print("hello functions!!! ") 


main()